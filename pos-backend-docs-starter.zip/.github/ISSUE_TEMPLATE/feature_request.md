---
name: Feature request
about: 새로운 기능을 제안합니다
labels: enhancement
---

## 제안 배경/목표

## 요구사항(유스케이스)

## 고려사항(보안/성능/운영)