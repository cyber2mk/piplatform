# API 계약/스냅샷 관리
- Swagger JSON 스냅샷 파일을 날짜별로 보관합니다.
- 변경점(브레이킹 체인지)은 `CHANGELOG.md`에 요약합니다.