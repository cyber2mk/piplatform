# DB 문서 가이드
- `dictionary.md`: 서비스 테이블 사전(설명/타입/제약/인덱스)
- `erd/`: ERD 이미지(png/svg), Draw.io 원본(.drawio) 보관
- `migrations_notes/`: 마이그레이션 설명/체크리스트(사람이 읽는 문서)
- GitHub의 `prisma/schema.prisma`, `prisma/migrations/`가 *실제 진실(Source of Truth)* 입니다.