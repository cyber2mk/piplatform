# 테이블 사전(Dictionary) 초안
> Drive의 GSheet와 병행 관리 권장. 여기에는 개요만 남기고, 상세 표는 GSheet 링크를 첨부하세요.

## users
| Column | Type | Null | Default | Description |
| --- | --- | --- | --- | --- |
| id | BIGINT UNSIGNED | NO | AUTO | PK |
| email | VARCHAR(255) | NO |  | unique |
| created_at | TIMESTAMP | NO | CURRENT_TIMESTAMP | 생성일 |

## shops
| Column | Type | Null | Default | Description |
| --- | --- | --- | --- | --- |
| id | BIGINT UNSIGNED | NO | AUTO | PK |
| name | VARCHAR(255) | NO |  |  |