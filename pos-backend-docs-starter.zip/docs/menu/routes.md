# 메뉴트리 & 라우팅 & 권한표
## ADMIN
- /admin/dashboard (Role: ADMIN)
- /admin/shops (Role: ADMIN)

## SHOP
- /shop/dashboard (Role: OWNER|STAFF)
- /shop/services (Role: OWNER|STAFF)

## CONSUMER
- / (public)
- /booking (Role: AUTHENTICATED)

> 프런트(Next.js) 라우팅 및 백엔드 RBAC 가드 매핑을 함께 관리하세요.