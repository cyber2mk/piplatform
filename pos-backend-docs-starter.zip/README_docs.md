# docs + .github 스타터 사용법

## 설치
1) 압축을 풀어 리포 루트(예: `piplatform/`)에 **병합**합니다.
2) 다음 명령으로 커밋/푸시:
   ```bash
   git add docs .github CODEOWNERS README_docs.md
   git commit -m "chore(docs): add docs/ and .github templates (2025-08-30)"
   git push origin main
   ```

## 운용 규칙(권장)
- `prisma/schema.prisma`, `prisma/migrations/` → **실제 진실**
- `docs/db/dictionary.md` → 개요만, 상세 표는 Drive GSheet에 관리 후 링크
- `docs/api/swagger_snapshot_YYYY-MM-DD.json` → 스냅샷 추가 시 `CHANGELOG.md`에 브레이킹 체인지 요약
- `docs/adr/ADR-XXXX_...md` → Drive의 ADR 번호와 동일하게 맞추기
- 이슈/PR 템플릿으로 협업 표준화